import json
import random
import string

from datetime import date
today = date.today()

daily_freebie_items = [45, 1, 41, 38]

daily_freebie_item_chance = random.randint(1, 60000)

jackpot_values = [200, 300, 500, 700, 600, 650, 620, 250, 350, 450, 470]



if daily_freebie_item_chance >= 40000:
	jackpot_state = 1
	random_cumulative = random.randint(10, 50)
else:
	jackpot_state = 2
	random_cumulative = random.choice(jackpot_values)

random_generic_offer = random.randint(1, 50000000)




# List of possible backgrounds
offers_background = [
    "offer_generic", "offer_special", "offer_legendary", "offer_finals", 
    "offer_chromatic", "offer_archive", "offer_random", "offer_velocirapids", 
    "offer_onceupon", "offer_pinpack", "offer_retrto", "offer_brawloween", 
    "offer_brawlywood", "offer_blackfriday", "offer_singlesday", "offer_brawlidays", 
    "offer_mrbeast", "offer_biodome", "offer_easter22", "offer_esports22", 
    "offer_ramadan22", "offer_gw2022", "offer_starter", "offer_stuntshow", 
    "offer_villains", "offer_deepsea", "offer_moonfestival22", "offer_robotfactory", 
    "offer_brawloween22", "offer_action", "offer_lastbox", "offer_4thanniversary", 
    "offer_lny23red", "offer_lny23green", "offer_candyland", "offer_darkmas", 
    "offer_brawlentines23", "offer_ramadan2023", "offer_easter2023", "offer_popstar", 
    "offer_gw2023", "offer_jungle", "offer_olympus", "offer_enchanted", 
    "offer_cursed", "offer_football2023", "offer_phoenix", "offer_overcharge", 
    "offer_mecha_edgar", "offer_university", "offer_mf2023", "offer_wasteland", 
    "offer_rarity_rare", "offer_rarity_super_rare", "offer_rarity_epic", "offer_rarity_mythic", 
    "offer_rarity_legendary", "offer_rarity_chromatic", "offer_legendary_dark"
]

# Your random_slot_offers list
random_slot_offers = [
{"Item": 41, "Title": 'PROMOTION TO INCREASE THE LEVEL', "Cost": 29, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'PROMOTION TO INCREASE THE LEVEL', "Cost": 29, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'SPECIAL PROMOTION', "Cost": 99, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'SPECIAL PROMOTION', "Cost": 29, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'SPECIAL PROMOTION', "Cost": 29, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'SPECIAL PROMOTION', "Cost": 29, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'SPECIAL PROMOTION', "Cost": 29, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'SPECIAL PROMOTION', "Cost": 49, "BGR": 'random.choice(offers_background)', "Amount": 250, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'SPECIAL PROMOTION', "Cost": 79, "BGR": 'random.choice(offers_background)', "Amount": 500, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'SPECIAL PROMOTION', "Cost": 79, "BGR": 'random.choice(offers_background)', "Amount": 500, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'SPECIAL PROMOTION', "Cost": 99, "BGR": 'random.choice(offers_background)', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}

]


# Replace 'BGR' in each offer
for offer in random_slot_offers:
    offer['BGR'] = random.choice(offers_background)





class Player:
    ClientVersion = "0.0.0"

    ID = [0, 1]
    Token = ""
    Name = "Brawler"
    Registered = False
    Thumbnail = 0
    Namecolor = 0
    Region = "CA"
    ContentCreator = "BSDS"

    Coins = 500
    Gems = 99999
    StarPoints = 0
    Trophies = 99999
    HighestTrophies = 99999
    TrophyRoadTier = 1
    Experience = 0
    Level = 0
    Tokens = 0
    TokensDoubler = 1000
    Bling = 0
    ChromaticCoins = 0
    RecruitTokens = 0
    PowerPoints = 0

    SelectedSkin = 0
    SelectedBrawler = 0
    RandomizerSelectedSkins = []
    OwnedPins = []
    OwnedThumbnails = []
    OwnedSkins = []
    OwnedBrawlers = {
        0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'MasteryPoints': 0, 'MasteryTier': 0},
    }
    OwnedTitles = []
    OwnedAccessories = []
    
    # Basic Shop
    GatchaItems = {}
    PurchasedOffers = []
    
    # Brawl Pass
    Pass32Int = 0
    Pass64Int = 0
    Pass96Int = 0
    
    Pass32IntP = 0
    Pass64IntP = 0
    Pass96IntP = 0
    
    
    BrawlPassActive = False
    
    # Road Data
    RoadType = 0
    PassLevel = 0
    PassSeason = 0
    
    # Starr Road    
    RecruitBrawler = 1
    RecruitCost = 160
    RecruitGemsCost = 29
    RecruitBrawlerCard = 4
    
    # Profile 
    BattleIcon1 = 0
    BattleIcon2 = 0
    BattleEmote = 0
    Title = 0
    
    BattleIcon1Visible = False
    BattleIcon2Visible = False
    BattleEmoteVisible = False
    TitleVisible = False
    
    FavouriteBrawler = 0
    
    
    # dont mind this shit
    Brawlers = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,34,36,37,40,42,43,45,47,48,50,52,58,61,63,64,67,69,71, 73]
    
    # Starr Drops   
    DropRarity = None
    DropAmount = 0
    DailyWins = 0
    
    # Notifications
    
    # SeenNotifications - scrapped feature
    SeenNotifications = []
    
    Notifications = [{"Type": 64, "Readed": False,"Timer": 432000, "Text": "FREE GEMS FOR LOGIN IN COMBAT BRAWL", "RewardType": 16, "Amount": 100, "Number": 0, "ItemName": "Gems", "Extra": 0, "Brawler": 0, "BrawlerCard": 0, "BrawlerPower": 1, "StarrDrops": False}]
    
    Quests = [{"MissionType": 1, "AchievedGoal": 1, "QuestGoal": 5000, "GameMode": 3, "Brawler": 0, "QuestReward": 1, "Amount": 500, "CurrentLevel": 0, "MaxLevel": 0, "Time": 99999, "NeedsPass": False, "Complete": False, "Number": 0}]
    
    # Daily Login Calendar
    ClaimedLoginRewardIndex = -1
    LoginRewardIndex = 0
    
    # Login Date
    LoginDay = int(today.strftime("%-d"))
    LoginMonth = int(today.strftime("%-m"))
    LoginYear = int(today.strftime("%Y"))
    
    # Daily Freebie
    DailyFreebieItem = random.choice(daily_freebie_items)
    DailyFreebieItemAmount = random_cumulative
    DailyFreebieClaimed = False
    Jackpot = jackpot_state
    
    # Random Offer Generation
    
    OfferSlot1 = [random.choice(random_slot_offers)]
    
    OfferSlot2 = [random.choice(random_slot_offers)]
    
    OfferSlot3 = [random.choice(random_slot_offers)]
    
    
    

    def __init__(self):
        pass

    def getDataTemplate(self, highid, lowid, token):
        if highid == 0 or lowid == 0:
            self.ID[0] = int(''.join([str(random.randint(0, 9)) for _ in range(1)]))
            self.ID[1] = int(''.join([str(random.randint(0, 9)) for _ in range(8)]))
            self.Token = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(40))
        else:
            self.ID[0] = highid
            self.ID[1] = lowid
            self.Token = token

        DBData = {
            'ID': self.ID,
            'Token': self.Token,
            'Name': self.Name,
            'Registered': self.Registered,
            'Thumbnail': self.Thumbnail,
            'Namecolor': self.Namecolor,
            'Region': self.Region,
            'ContentCreator': self.ContentCreator,
            'Coins': self.Coins,
            'Gems': self.Gems,
            'StarPoints': self.StarPoints,
            'Trophies': self.Trophies,
            'HighestTrophies': self.HighestTrophies,
            'TrophyRoadTier': self.TrophyRoadTier,
            'Experience': self.Experience,
            'Level': self.Level,
            'Tokens': self.Tokens,
            'TokensDoubler': self.TokensDoubler,
            'SelectedBrawler': self.SelectedBrawler,
            'SelectedSkin': self.SelectedSkin,
            'OwnedPins': self.OwnedPins,
            'OwnedThumbnails': self.OwnedThumbnails,
            'OwnedBrawlers': self.OwnedBrawlers,
            'OwnedSkins': self.OwnedSkins,
            'OwnedTitles': self.OwnedTitles,
            'OwnedAccessories': self.OwnedAccessories,
            'Bling': self.Bling,
            'ChromaticCoins': self.ChromaticCoins,
            'RecruitTokens': self.RecruitTokens,
            'PowerPoints': self.PowerPoints,
            'GatchaItems': self.GatchaItems,
            'PurchasedOffers': self.PurchasedOffers,
            'Pass32Int': self.Pass32Int,
            'Pass64Int': self.Pass64Int,
            'Pass96Int': self.Pass96Int,
            'Pass32IntP': self.Pass32IntP,
            'Pass64IntP': self.Pass64IntP,
            'Pass96IntP': self.Pass96IntP,
            'BrawlPassActive': self.BrawlPassActive,
            'RoadType': self.RoadType,
            'PassLevel': self.PassLevel,
            'PassSeason': self.PassSeason,
            'RecruitBrawler': self.RecruitBrawler,
            'RecruitCost': self.RecruitCost,
            'RecruitGemsCost': self.RecruitGemsCost,
            'RecruitBrawlerCard': self.RecruitBrawlerCard,
            'Brawlers': self.Brawlers,
            'BattleIcon1': self.BattleIcon1,
            'BattleIcon2': self.BattleIcon2,
            'BattleEmote': self.BattleEmote,
            'Title': self.Title,
            'BattleIcon1Visible': self.BattleIcon1Visible,
            'BattleIcon2Visible': self.BattleIcon2Visible,
            'BattleEmoteVisible': self.BattleEmoteVisible,
            'TitleVisible': self.TitleVisible,
            'FavouriteBrawler': self.FavouriteBrawler,
            'DropRarity': self.DropRarity,
            'DropAmount': self.DropAmount,
            'SeenNotifications': self.SeenNotifications,
            'Notifications': self.Notifications,
            'Quests': self.Quests,
            'ClaimedLoginRewardIndex': self.ClaimedLoginRewardIndex,
            'LoginRewardIndex': self.LoginRewardIndex,
            'DailyWins': self.DailyWins,
            'LoginDay': self.LoginDay,
            'LoginMonth': self.LoginMonth,
            'LoginYear': self.LoginYear,
            'DailyFreebieItem': self.DailyFreebieItem,
            'DailyFreebieItemAmount': self.DailyFreebieItemAmount,
            'DailyFreebieClaimed': self.DailyFreebieClaimed,
            'OfferSlot1': self.OfferSlot1,
            'OfferSlot2': self.OfferSlot2,
            'OfferSlot3': self.OfferSlot3,
            'Jackpot': self.Jackpot
            
        }
        return DBData

    def toJSON(self):
        return json.loads(json.dumps(self, default=lambda o: o.__dict__,
            sort_keys=True, indent=4))