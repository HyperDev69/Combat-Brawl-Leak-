from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Readers.CSVReaders.Cards import Cards
import json

class LogicPurchaseBrawlerCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        fields["Tick1"] = calling_instance.readVInt()
        fields["Unk1"] = calling_instance.readVInt()
        fields["Unk2"] = calling_instance.readVInt()
        fields["VInst1"] = calling_instance.readVInt()
        fields["BrawlerID"] = calling_instance.readDataReference()
        fields["Unk3"] = calling_instance.readVInt()
        fields["Unk"] = calling_instance.readVInt()
        print(fields["Tick1"])
        print(fields["Unk1"])
        print(fields["Unk2"])
        print(fields["VInst1"])
        print(fields["BrawlerID"])
        print(fields["Unk3"])
        print(fields["Unk"])
        return fields
    
    
    	
    		

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        fields["IsBrawlPassReward"] = False
        
        box = {'Type': 100, 'Items': []}
        
        def giveDeliveryBrawler(brawler, card, powerlevel):
        	playerData["OwnedBrawlers"][brawler] = {'CardID': card, 'Skins': [0], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': powerlevel, 'PowerPoints': 0, 'State': 2, 'MasteryPoints': 0, 'MasteryTier': 0}
        	playerData["GatchaItems"] = {'Boxes': []}	
        	item = {'Amount': 1, 'DataRef': [16, brawler],  'RewardID': 1}
        	box['Items'].append(item)
        	playerData["GatchaItems"]['Boxes'].append(box)
        	
        def changeResourceNegative(resource, amount):
        	playerData[resource] -= amount        	              
        def sendDelivery():
        	db_instance.updatePlayerData(playerData, calling_instance)
        	fields["StarrDrops"] = False
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	        	        	
        def clearBox():
        	box['Items'].clear()
        
        
        if fields["BrawlerID"][1] == 35:
        	CardID = 224#гейл
        if fields["BrawlerID"][1] == 38:
        	CardID = 279#вольт
        if fields["BrawlerID"][1] == 39:
        	CardID =296#колет
        if fields["BrawlerID"][1] == 41:
        	CardID =320#лу
        if fields["BrawlerID"][1] == 44:
        	CardID =341#гавс
        if fields["BrawlerID"][1] == 46:
        	CardID =365#бель
        if fields["BrawlerID"][1] == 49:
        	CardID =386#баз
        if fields["BrawlerID"][1] == 51:
        	CardID =410#эш
        if fields["BrawlerID"][1] == 53:
        	CardID =427#лола
        if fields["BrawlerID"][1] == 54:
        	CardID =434#фэнг
        if fields["BrawlerID"][1] == 56:
        	CardID =448#ева
        if fields["BrawlerID"][1] == 57:
        	CardID =466#сранет
        if fields["BrawlerID"][1] == 59:
        	CardID =491#отис
        if fields["BrawlerID"][1] == 60:
        	CardID =499#сэм
        if fields["BrawlerID"][1] == 62:
        	CardID =515#бимбастер
        if fields["BrawlerID"][1] == 65:
        	CardID =539#мэнди
        if fields["BrawlerID"][1] == 66:
        	CardID =547#р-т
        if fields["BrawlerID"][1] == 68:
        	CardID =565#мэйси
        if fields["BrawlerID"][1] == 70:
        	CardID =581#корделиус
        	
        if fields["Unk"] == 20:
        	giveDeliveryBrawler(fields["BrawlerID"][1], CardID, 1)
        	if fields["BrawlerID"][1] == 68:
        		changeResourceNegative("ChromaticCoins", 1250)
        	else:
        		changeResourceNegative("ChromaticCoins", 500)
        	sendDelivery()
        	clearBox()
        	
        
        if fields["Unk"] == 0:
        	giveDeliveryBrawler(fields["BrawlerID"][1], CardID, 1)
        	if fields["BrawlerID"][1] == 68:
        		changeResourceNegative("Gems", 349)
        	else:
        		changeResourceNegative("Gems", 169)
        	sendDelivery()
        	clearBox()
        		
        		
        	

    def getCommandType(self):
        return 560