from Classes.ByteStream import ByteStream
from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json
import random

from Classes.Readers.CSVReaders.Cards import Cards


class LogicPurchaseAccessoryCommand(LogicServerCommand):
    
    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["Item"] = calling_instance.readVInt()
        fields["Type"] = calling_instance.readVInt()
        
        LogicCommand.parseFields(fields)
        return fields

    def encode(self, fields):
    	pass

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        AccessoryPrice = Cards.getAccessoryPrice(fields["Item"])
        playerData["OwnedAccessories"].append(fields["Item"])
        print("Current Accessory Price:", AccessoryPrice)
        playerData["Coins"] -= int(AccessoryPrice)
        db_instance.updatePlayerData(playerData, calling_instance)


    def getCommandType(self):
        return 557



