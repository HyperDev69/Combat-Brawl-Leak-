from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Classes.Logic.LogicStarrDropData import starrDropOpening
from Database.DatabaseHandler import DatabaseHandler

from Classes.Readers.CSVReaders.Skins import Skins
from Classes.Readers.CSVReaders.Pins import Emotes
from Classes.Readers.CSVReaders.PlayerThumbnails import PlayerThumbnails

from Classes.Readers.JSONReaders.Cards import CardFetcher

import json
import random

from JSON.JSONHandler import JSONHandler

class LogicPurchaseOfferCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        self.writeVInt(0)
        self.writeDataReference(0)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["OfferIndex"] = calling_instance.readVInt()
        fields["PurchasedItem"] = calling_instance.readDataReference()
        fields["Unk"] = calling_instance.readDataReference()
        fields["CurrencySlot"] = calling_instance.readVInt()

        
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        
        fields["IsBrawlPassReward"] = False
        
        ShopData = JSONHandler.ShopData
        
        # Player Data Entry
        
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        # Get Random Value
        
        def getRandomValue():
        	return random.randint(1, 2250)
        	
        # Create Starr Drop
        
        def encodeStarrDrop(rarity, amount):	
        	if rarity == 0:
        		a = JSONHandler.RareDropsData
        		fields["Rarity"] = 0
        	elif rarity == 1:
        		a = JSONHandler.SuperRareDropsData
        		fields["Rarity"] = 1
        	elif rarity == 2:
        		a = JSONHandler.EpicDropsData
        		fields["Rarity"] = 2
        	elif rarity == 3:
        		a = JSONHandler.MythicDropsData
        		fields["Rarity"] = 3
        	elif rarity == 4:
        		a = JSONHandler.LegendaryDropsData
        		fields["Rarity"] = 4       
        	elif rarity == 5:
        		a = JSONHandler.LegendaryDropsData
        		fields["Rarity"] = 5	
        	playerData["DropRarity"] = fields["Rarity"]
        	for i in a["DropsData"]:
        		item = random.choice(i["Items"])
        		ItemID = item["ItemID"]       			
        		Fallback = random.randint(item["MinFallback"], item["MaxFallback"])
        		DeliveryID = item["DeliveryID"]
        		DataRef = item["DataRef"]
        		if ItemID == "OwnedPins":
        			RandomItem = random.randint(52, 1000)
        		elif ItemID == "Spyrays":
        			RandomItem = random.randint(17, 191)
        		else:
        			RandomItem = random.randint(12, 100)
        	
        			
        	playerData["GatchaItems"] = {'Boxes': []}
        	box = {'Type': 0, 'Items': []}	
        	item = {'Amount': Fallback, 'DataRef': [DataRef, RandomItem],  'RewardID': DeliveryID}
        	box['Items'].append(item)
        	box['Type'] = 100
        	playerData["GatchaItems"]['Boxes'].append(box)
        	DeprecatedItems = ["OwnedPins", "OwnedThumbnails", "Spyrays"]
        	if ItemID not in DeprecatedItems:
        		SaveList = [] 
        		SaveList.append(Fallback)
        		playerData[ItemID] += SaveList[0]
        		SaveList.clear()
        	else:
        		SaveList = []
        		SaveList.append(RandomItem)
        		playerData[ItemID].append(SaveList[0])
        		SaveList.clear()
        	for i in ShopData["Offers"]:
        		if fields["OfferIndex"] == ShopData["Offers"].index(i):
        			playerData["PurchasedOffers"].append(ShopData["Offers"].index(i) - 1)	
        	playerData["DropAmount"] = amount
        	if amount == 1:
        		db_instance.updatePlayerData(playerData, calling_instance)
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 228}
        		fields["PlayerID"] = calling_instance.player.ID
        		fields["StarrDrops"] = True
        		fields["Offer"] = fields["OfferIndex"]
        		fields["Wins"] = playerData["DailyWins"]
        		Messaging.sendMessage(24111, fields, cryptoInit) 
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 203}
        		fields["StarrDrops"] = True
        		fields["PlayerID"] = calling_instance.player.ID
        		Messaging.sendMessage(24111, fields, cryptoInit)
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 228}
        		fields["PlayerID"] = calling_instance.player.ID
        		fields["StarrDrops"] = False
        		fields["Offer"] = fields["OfferIndex"]
        		fields["Wins"] = playerData["DailyWins"]
        		Messaging.sendMessage(24111, fields, cryptoInit)
        	
        	else:
        		playerData["DropAmount"] -= 1
        		db_instance.updatePlayerData(playerData, calling_instance)
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 228}
        		fields["PlayerID"] = calling_instance.player.ID
        		fields["StarrDrops"] = True
        		fields["Offer"] = fields["OfferIndex"]
        		fields["Wins"] = playerData["DailyWins"]
        		Messaging.sendMessage(24111, fields, cryptoInit) 
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 203}
        		fields["StarrDrops"] = True
        		fields["PlayerID"] = calling_instance.player.ID
        		fields["Wins"] = playerData["DailyWins"]
        		Messaging.sendMessage(24111, fields, cryptoInit)
        	
        	
        	
        	
        # Define Boxes
        		
        box = {'Type': 100, 'Items': []}
        boxVanity = {'Type': 100, 'Items': []}
        
        # Give Out Resource
        
        def giveDeliveryResources(type, amount):
        	playerData[type] += amount
        	if type == "Coins":
        		boxType = 7
        	if type == "Gems":
        		boxType = 8
        	if type == "Bling":
        		boxType = 25
        	if type == "RecruitTokens":
        		boxType = 22
        	if type == "ChromaticCoins":
        		boxType = 23
        	if type == "PowerPoints":
        		boxType = 24
        	playerData["GatchaItems"] = {'Boxes': []}	
        	item = {'Amount': amount, 'DataRef': [0, 0],  'RewardID': boxType}
        	box['Items'].append(item)
        	playerData["GatchaItems"]['Boxes'].append(box)
        	
        # Give Out Vanity
        
        def giveDeliveryVanity(type, amount, skin):
        	playerData[type].append(skin)
        	if type == "OwnedPins":
        		boxType = 52
        	if type == "OwnedThumbnails":
        		boxType = 28
        	playerData["GatchaItems"] = {'Boxes': []}
        		
        	item = {'Amount': amount, 'DataRef': [boxType, skin],  'RewardID': 11}
        	boxVanity['Items'].append(item)
        	if len(box["Items"]) != 0:
        		playerData["GatchaItems"]['Boxes'].append(box)
        	playerData["GatchaItems"]['Boxes'].append(boxVanity)
        	
        # Give Out Skin
        	
        def giveDeliverySkin(skin):
        	playerData["OwnedSkins"].append(skin)
        	playerData["GatchaItems"] = {'Boxes': []}	
        	item = {'Amount': 1, 'DataRef': [29, skin],  'RewardID': 9}
        	box['Items'].append(item)
        	playerData["GatchaItems"]['Boxes'].append(box)
        	
        	
        # Give Out Accessory
        
        def giveDeliveryAccessory(accessory):
        	playerData["OwnedAccessories"].append(accessory)
        	playerData["GatchaItems"] = {'Boxes': []}	
        	item = {'Amount': 1, 'DataRef': [23, accessory],  'RewardID': 4}
        	box['Items'].append(item)
        	playerData["GatchaItems"]['Boxes'].append(box)
        	
        # Give Out Brawler
        
        def giveDeliveryBrawler(brawler, card, powerlevel):
        	playerData["OwnedBrawlers"][brawler] = {'CardID': card, 'Skins': [0], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': powerlevel, 'PowerPoints': 0, 'State': 2, 'MasteryPoints': 0, 'MasteryTier': 0}
        	playerData["GatchaItems"] = {'Boxes': []}	
        	item = {'Amount': 1, 'DataRef': [16, brawler],  'RewardID': 1}
        	box['Items'].append(item)
        	playerData["GatchaItems"]['Boxes'].append(box)
        	
        # Subtract Resource
        	
        def changeResourceNegative(resource, amount):
        	playerData[resource] -= amount
        	
        def claimDailyFreebie():
        	playerData["DailyFreebieClaimed"] = True
        	
        # Send Server Command
        	        
        def sendCommand(command):
        	db_instance.updatePlayerData(playerData, calling_instance)
        	if command == 203:
        		fields["StarrDrops"] = False
        	else:
        		pass
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": command}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)       
        
	     
        # Clear Box After Delivery   	
        	
        def clearBox():
        	box['Items'].clear()
        	boxVanity['Items'].clear()
        
        def sendHome():
        	Messaging.sendMessage(24101, fields, cryptoInit, calling_instance.player)
        	
        # Get Resource Type By ID
        	
        def specializeResource(intType, amount):
        	if intType == 1:
        		resource = "Coins"
        	elif intType == 16:
        		resource = "Gems"
        	elif intType == 45:
        		resource = "Bling"
        	elif intType == 38:
        		resource = "RecruitTokens"
        	elif intType == 39:
        		resource = "ChromaticCoins"
        	elif intType == 41:
        		resource = "PowerPoints"
        	giveDeliveryResources(resource, amount)
        	
        # Get Vanity Type By ID
        
        def specializeVanity(intType, amount, extra):
        	if intType == 19:
        		vanity = "OwnedPins"
        	elif intType == 25:
        		vanity = "OwnedThumbnails"
        	giveDeliveryVanity(vanity, amount, extra)
        	
        	
        		
        	
        	
        	
        	
        # JSON Shop Reader
        if fields["OfferIndex"] == 0:
        	if playerData["DailyFreebieClaimed"] == False:
        		specializeResource(playerData["DailyFreebieItem"], playerData["DailyFreebieItemAmount"])
        		claimDailyFreebie()
        		sendCommand(203)
        		clearBox()
        	else:
        		pass
       
        if fields["OfferIndex"] == 1:
        	specializeResource(playerData["OfferSlot1"][0]["Item"], playerData["OfferSlot1"][0]["Amount"])
        	playerData["OfferSlot1"][0]["Claimed"] = True
        	changeResourceNegative("Gems", playerData["OfferSlot1"][0]["Cost"])
        	sendCommand(203)
        	clearBox()
        
        if fields["OfferIndex"] == 2:
        	specializeResource(playerData["OfferSlot2"][0]["Item"], playerData["OfferSlot2"][0]["Amount"])
        	playerData["OfferSlot2"][0]["Claimed"] = True
        	changeResourceNegative("Gems", playerData["OfferSlot2"][0]["Cost"])
        	sendCommand(203)
        	clearBox()
        
        if fields["OfferIndex"] == 3:
        	specializeResource(playerData["OfferSlot3"][0]["Item"], playerData["OfferSlot3"][0]["Amount"])
        	playerData["OfferSlot3"][0]["Claimed"] = True
        	changeResourceNegative("Gems", playerData["OfferSlot3"][0]["Cost"])
        	sendCommand(203)
        	clearBox()
        	
        	
        for i in ShopData["Offers"]:
        	if fields["OfferIndex"] == ShopData["Offers"].index(i) + 4:
        		AppendableItems = [25, 19]
        		for reward in i["Rewards"]:
        			DropRarity = reward["Extra"]
        			if reward["ItemType"] in AppendableItems:
        				specializeVanity(reward["ItemType"], 1, reward["Extra"])
        			
        			elif reward["ItemType"] == 3:
        				BrawlerCard = CardFetcher.fetchBrawlerCard(reward["BrawlerID"][1])
        				giveDeliveryBrawler(reward["BrawlerID"][1], int(BrawlerCard["CardID"]), reward["BrawlerPower"])
        			elif reward["ItemType"] == 4:
        				giveDeliverySkin(reward["Extra"])
        			elif reward["ItemType"] == 5:
        				giveDeliveryAccessory(reward["Extra"])
        			elif reward["ItemType"] == 49:
        				if i["PortaliumStarrDrop"] == False:
        					encodeStarrDrop(reward["Extra"], reward["Amount"])
        				else:
        					encodeStarrDrop(5, reward["Amount"])
        					
        			else:
        				specializeResource(reward["ItemType"], reward["Amount"])
        			if i["BundleID"] != "None":
        				playerData["PurchasedOffers"].append(i["BundleID"])
        		if i["Currency"] == 0:
        			changeResourceNegative("Gems", i["Cost"])
        		elif i["Currency"] == 1:
        			changeResourceNegative("Coins", i["Cost"])
        		elif i["Currency"] == 3:
        			changeResourceNegative("Bling", i["Cost"])
        		else:
        			pass
        		if i["StarrDrops"] == True:
        			clearBox()
        		elif i["UpdateOffers"] == True:
        			sendCommand(203)
        			sendCommand(211)
        			clearBox()
        		else:
        			sendCommand(203)
        			clearBox()
        	
        	
        
        # Catalog Skin Logic
        
        if fields["PurchasedItem"][0] == 29 and fields["PurchasedItem"] != None:
        	giveDeliverySkin(fields["PurchasedItem"][1])
        	SkinData = Skins.getCostSkinByID(fields["PurchasedItem"][1])
        	print(SkinData)
        	if fields["CurrencySlot"] == 1:
        		changeResourceNegative("Gems", int(SkinData["Diamonds"]))
        	if fields["CurrencySlot"] == 2:
        		changeResourceNegative("Bling", int(SkinData["Bling"]))
        	sendCommand(203)
        	clearBox()
        	
        # Catalog Emote Logic
        
        if fields["PurchasedItem"][0] == 52:
        	giveDeliveryVanity("OwnedPins", 1, fields["PurchasedItem"][1])
        	EmoteData = Emotes.getCostPinsByID(fields["PurchasedItem"][1])
        	print(EmoteData)
        	if fields["CurrencySlot"] == 1:
        		changeResourceNegative("Gems", int(EmoteData["Diamonds"]))
        	if fields["CurrencySlot"] == 2:
        		changeResourceNegative("Bling", int(EmoteData["Bling"]))
        	sendCommand(203)
        	clearBox()
        
        # Catalog Thumbnail Logic
        
        if fields["PurchasedItem"][0] == 28:
        	giveDeliveryVanity("OwnedThumbnails", 1, fields["PurchasedItem"][1])
        	ThumbnailData = PlayerThumbnails.getCostThumbnailsByID(fields["PurchasedItem"][1])
        	if fields["CurrencySlot"] == 1:
        		changeResourceNegative("Gems", int(ThumbnailData["Diamonds"]))
        	if fields["CurrencySlot"] == 2:
        		changeResourceNegative("Bling", int(ThumbnailData["Bling"]))
        	sendCommand(203)
        	clearBox()
        	
        
        	
        
        


    def getCommandType(self):
        return 519