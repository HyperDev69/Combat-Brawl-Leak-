import traceback

class Messaging:
    @staticmethod
    def writeHeader(message, payloadLen):
        # Writing the header to the message buffer
        message.messageBuffer += message.getMessageType().to_bytes(2, 'big', signed=True)
        message.messageBuffer += payloadLen.to_bytes(3, 'big', signed=True)
        message.messageBuffer += message.messageVersion.to_bytes(2, 'big', signed=True)

    @staticmethod
    def readHeader(headerBytes):
        # Reading the header from the provided bytes
        headerData = []
        headerData.append(int.from_bytes(headerBytes[:2], 'big', signed=True))
        headerData.append(int.from_bytes(headerBytes[2:5], 'big', signed=True))
        return headerData

    @staticmethod
    def sendMessage(messageType, fields, cryptoInit, player=None):
        from Classes.Logic.LogicLaserMessageFactory import LogicLaserMessageFactory
        
        # Create message by type using the factory
        message = LogicLaserMessageFactory.createMessageByType(messageType, b'')
        
        if message is None:
            raise ValueError(f"Message type {messageType} is not recognized by the factory.")

        # Encode the message
        if player is not None:
            message.encode(fields, player)
        else:
            message.encode(fields)
        
        # Encrypt the message payload
        message.messagePayload = cryptoInit.encryptServer(message.getMessageType(), message.messagePayload)
        
        # Write the header
        Messaging.writeHeader(message, len(message.messagePayload))
        
        # Append the payload to the message buffer
        message.messageBuffer += message.messagePayload
        
        # Send the message
        try:
            fields["Socket"].send(message.messageBuffer)
        except Exception:
            # Print the stack trace in case of an exception
            print(traceback.format_exc())
