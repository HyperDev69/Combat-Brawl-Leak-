from Classes.Packets.PiranhaMessage import PiranhaMessage

class TeamGameStartingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0 

    def encode(self, fields, player):
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24130

    def getMessageVersion(self):
        return self.messageVersion