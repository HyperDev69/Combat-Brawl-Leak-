from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.BitStream import BitStream

class VisionUpdateMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0 #24109

    def encode(self, fields, player):
    	self.writeVInt(fields["battleTick"]) # battle ticks
    	self.writeVInt(0) # wifi array
    	self.writeVInt(0) # command amount
    	self.writeVInt(fields["battleTick"]) # spectators
    	self.writeBoolean(True) # live 
    	
    	stream = BitStream()
    	b = BitStream()
    	
    	stream.writePositiveInt(1000000 + 0, 21)
    	stream.writePositiveInt(20, 1)
    	
    	stream.writeInt(-1, 4) #Win/Lose
    	
    	stream.writePositiveInt(1, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	
    	stream.writePositiveInt(0, 5)
    	stream.writePositiveInt(0, 6)
    	stream.writePositiveInt(1, 5)
    	stream.writePositiveInt(0, 6)
    	
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(1, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writeBoolean(False) # ultimate skill charged
    	
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 12) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1) #gadget use effect
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1) 
    	
    	for x in range(30):
    		stream.writePositiveInt(0, 1) 
    	
    	stream.writePositiveInt(0, 1) # map load
    	
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(1, 1)
    	
    	stream.writePositiveInt(1, 1)
    	
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	
    	
    	stream.WritePositiveVIntMax65535(1) # game object
    	
    	stream.writePositiveInt(16, 5) #type
    	stream.writePositiveInt(player.SelectedBrawlers[0], 9) #brawler
    	
    	# IDs start
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.WritePositiveVIntMax65535(0)
    	# IDs end
    	
    	# player start
    	stream.WritePositiveVIntMax65535(3150) # x
    	stream.WritePositiveVIntMax65535(6000) # y
    	stream.WritePositiveVIntMax65535(0) # z
    	stream.WritePositiveVIntMax255(0) #i
    	#stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(10, 4)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	
    	stream.writePositiveInt(0, 3)
    	stream.writePositiveInt(0, 1) #power
    	stream.writeInt(63, 6)
    	stream.writePositiveInt(0, 1)  #revert walk
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(1, 1) # sp indicator
    	
    	stream.WritePositiveVIntMax65535OftenZero(0) 
    	stream.WritePositiveVIntMax65535OftenZero(0) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1)
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1)
    	
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(1, 1) #заглушено тип да ех
    	
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	stream.writePositiveInt(0, 1) 
    	
    	stream.WritePositiveVIntMax255OftenZero(0) # Lou Freezing
    	stream.WritePositiveVIntMax255OftenZero(0) #Poison Type
    	stream.WritePositiveVIntMax255OftenZero(0)
    	stream.writePositiveVInt(2800, 4) 
    	stream.writePositiveVInt(2800, 4) 
    	stream.WritePositiveVIntMax65535OftenZero(10) #Items Count
    	
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	
    	stream.WritePositiveVIntMax255OftenZero(1)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	
    	stream.writeBoolean(True)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	
    	stream.writeBoolean(False) #
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	stream.writeBoolean(False)
    	
    	stream.writeBoolean(False)
    	stream.WritePositiveIntMax3(0)
    	
    	stream.writeBoolean(False)
    	stream.WritePositiveIntMax511(0)
    	
    	stream.WritePositiveIntMax3(0) # speed
    	stream.writeBoolean(False) # tara eye
    	
    	
    	stream.WritePositiveIntMax31(0)#damage array
    	
    	#LogicSkillServer::encode
    	stream.WritePositiveVIntMax255OftenZero(0)
    	stream.writeBoolean(False)
    	stream.WritePositiveVIntMax255OftenZero(0)
    	stream.WritePositiveIntMax4095(3000)
    	stream.writeBoolean(True)
    	stream.writeBoolean(False)
    	stream.writeBoolean(True)
    	#LogicSkillServer::encode end
    	# GameObjects end
    	
    	stream.writePositiveInt(0, 8) 
    	
    	self.writeBytes(stream.getBuff(), len(stream.getBuff()))
        
    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24109

    def getMessageVersion(self):
        return self.messageVersion