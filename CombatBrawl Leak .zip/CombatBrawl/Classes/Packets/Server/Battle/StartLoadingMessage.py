import time

from Classes.Packets.PiranhaMessage import PiranhaMessage


class StartLoadingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
    	
    	self.writeInt(1) # player amount
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeInt(1) 
    	for i in range(1):
    		self.writeLong(player.ID[0], player.ID[1]) # player id
    		
    		self.writeVInt(1) # team
    		self.writeVInt(0)
    		self.writeVInt(0)
    		
    		self.writeInt(0)
    		
    		self.writeBoolean(True) #hero update 
    		self.writeDataReference(16, player.SelectedBrawlers[0])
    		
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		self.writeDataReference(29, 0)
    		self.writeDataReference(0)
    		self.writeVInt(0)

    		
    		self.writeString(player.Name) #player name
    		
    		self.writeVInt(100)
    		self.writeVInt(28000000) #profile icon
    		self.writeVInt(43000000 + player.Namecolor) #namecolor
    		self.writeVInt(0) #brawl pass color
    		
    		self.writeBoolean(False) #boolean
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		self.writeVInt(0)
    		self.writeVInt(100000)
    		self.writeDataReference(28, 0)
    		self.writeDataReference(28, player.BattleMapIcon2)
    		self.writeDataReference(52, player.BattleMapPin)
    		self.writeDataReference(76, player.BattleMapTitle)
    		
    		self.writeVInt(player.MasteryPoints[f"{int(player.SelectedBrawlers[0])}"])
    		
    		
    	
    	self.writeInt(0)
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeVInt(25)
    	self.writeVInt(1) # map load
    	self.writeVInt(25)
    	self.writeVInt(0)
    	
    	self.writeBoolean(False) 
    	self.writeVInt(0)#is spectating
    	self.writeVInt(0)
    	self.writeDataReference(15, 479) #map
    	self.writeBoolean(False)
    	
    	self.writeBoolean(False)
    	self.writeBoolean(False)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeBoolean(False)
    	
    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20559

    def getMessageVersion(self):
        return self.messageVersion