from Classes.ByteStreamHelper import ByteStreamHelper
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Logic.LogicStarrDropData import starrDropOpening
from Classes.Logic.Quest import Quest
from Static.StaticData import StaticData	

from JSON.JSONHandler import JSONHandler

from datetime import datetime 

import random

from Database.DatabaseHandler import DatabaseHandler

import Configuration

class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        seasonTime = datetime.strptime("17.11.2024 18:00", "%d.%m.%Y %H:%M").timestamp()
        seasonTimeEquation = seasonTime - datetime.now().timestamp()
        
        		
        	
        	
        ownedBrawlersCount = len(player.OwnedBrawlers)
        ownedPinsCount = len(player.OwnedPins)
        ownedThumbnailCount = len(player.OwnedThumbnails)
        ownedSkins = len(player.OwnedSkins)
        ownedTitlesCount = len(player.OwnedTitles)
        self.writeVInt(1688816070) 
        self.writeVInt(1191532375)
        self.writeVInt(2023189) 
        self.writeVInt(73530) 
        self.writeVInt(player.Trophies) 
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(player.HighestTrophies) 
        self.writeVInt(player.TrophyRoadTier) 
        self.writeVInt(player.Experience) 
        self.writeDataReference(28, player.Thumbnail)
        self.writeDataReference(43, player.Namecolor)

        self.writeVInt(26) # played Game Mode
        for x in range(26):
            self.writeVInt(x)
            
        self.writeVInt(1)

        self.writeDataReference(29, player.SelectedSkin) # selected skin count

        self.writeVInt(0) # available ramdon skins

        self.writeVInt(0) # random skins
        
        self.writeVInt(len(player.OwnedSkins))
        for skinID in player.OwnedSkins:
            self.writeDataReference(29, skinID)

        self.writeVInt(0) # skin purchase option

        self.writeVInt(0) # unk skin array5

        self.writeVInt(0) # leaderboard region
        self.writeVInt(player.HighestTrophies) # highest trophies
        self.writeVInt(0) # tokens used in battle
        self.writeVInt(2) # control mode
        self.writeBoolean(True) # battle hints
        self.writeVInt(0) # token doubler left
        self.writeVInt(115) # maybe starr drop timer ? #v50
        self.writeVInt(335442) # trophy league timer
        self.writeVInt(1001442) # power play timer
        self.writeVInt(int(seasonTimeEquation)) # Brawl pass season timer
        #self.writeVInt(0) # maybe starr drop timer ? #v50

        self.writeVInt(120) # 
        self.writeVInt(200) # 
        self.writeVInt(0) # drop chance of characters in boxes
        # self.writeVInt(93)
        # self.writeVInt(206)
        # self.writeVInt(456)
        # self.writeVInt(1001)
        # self.writeVInt(2264)

        self.writeBoolean(True) # false, false, true
        self.writeVInt(2) # token doubler  new tag state
        self.writeVInt(2) # event tickets new tag state
        self.writeVInt(2) # coins pack new tag state
        self.writeVInt(0) # name change cost
        self.writeVInt(0) # timer for next name change
        
        ShopData = JSONHandler.ShopData
        
        
        self.writeVInt(len(ShopData["Offers"]) + 4) # LogicShopData
        
        self.writeVInt(1) # RewardCount

        self.writeVInt(player.DailyFreebieItem)  # ItemType
        self.writeVInt(player.DailyFreebieItemAmount) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        if player.DailyFreebieClaimed == False:
        	self.writeVInt(0) # Cost
        else:
        	self.writeVInt(99999)
        self.writeVInt(84600) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(player.DailyFreebieClaimed)
        self.writeVInt(1250)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeString("Daily Reward") # Text
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeString("None") # Background
        self.writeVInt(1)
        self.writeBoolean(True) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)       
        self.writeVInt(player.Jackpot)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(5)
        self.writeVInt(11)
        self.writeBoolean(False)
        
        self.writeVInt(1) # RewardCount

        self.writeVInt(player.OfferSlot1[0]["Item"])  # ItemType
        self.writeVInt(player.OfferSlot1[0]["Amount"]) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(player.OfferSlot1[0]["Cost"])
        self.writeVInt(84600) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(player.OfferSlot1[0]["Claimed"])
        self.writeVInt(1250)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(player.OfferSlot1[0]["OldCost"]) # Old price
        self.writeString(player.OfferSlot1[0]["Title"]) # Text
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeString(player.OfferSlot1[0]["BGR"]) # Background
        self.writeVInt(1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)       
        self.writeVInt(0)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(5)
        self.writeVInt(11)
        self.writeBoolean(False)
        
        self.writeVInt(1) # RewardCount

        self.writeVInt(player.OfferSlot2[0]["Item"])  # ItemType
        self.writeVInt(player.OfferSlot2[0]["Amount"]) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(player.OfferSlot2[0]["Cost"])
        self.writeVInt(84600) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(player.OfferSlot2[0]["Claimed"])
        self.writeVInt(1250)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(player.OfferSlot2[0]["OldCost"]) # Old price
        self.writeString(player.OfferSlot2[0]["Title"]) # Text
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeString(player.OfferSlot2[0]["BGR"]) # Background
        self.writeVInt(1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)       
        self.writeVInt(0)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(5)
        self.writeVInt(11)
        self.writeBoolean(False)
        
        self.writeVInt(1) # RewardCount

        self.writeVInt(player.OfferSlot3[0]["Item"])  # ItemType
        self.writeVInt(player.OfferSlot3[0]["Amount"]) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(player.OfferSlot3[0]["Cost"])
        self.writeVInt(84600) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(player.OfferSlot3[0]["Claimed"])
        self.writeVInt(1250)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(player.OfferSlot3[0]["OldCost"]) # Old price
        self.writeString(player.OfferSlot3[0]["Title"]) # Text
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeString(player.OfferSlot3[0]["BGR"]) # Background
        self.writeVInt(1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)       
        self.writeVInt(0)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(5)
        self.writeVInt(11)
        self.writeBoolean(False)
        

        for i in ShopData["Offers"]:
            def checkAvailability():
            	results = []
            	result = False
            	for reward in i["Rewards"]:
            		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
            			if str(reward["BrawlerID"][1]) in list(player.OwnedBrawlers.keys()):
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 19:
            			if reward["Extra"] in player.OwnedPins or i["IsForPortalEvent"] == True and str(i["NeedsBrawler"]) not in player.OwnedBrawlers:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 25:
            			if reward["Extra"] in player.OwnedThumbnails:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 4:
            			if reward["Extra"] in player.OwnedSkins or i["IsForPortalEvent"] == True and str(i["NeedsBrawler"]) not in player.OwnedBrawlers:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            	if i["Rewards"].index(reward) == len(i["Rewards"]) -1:
            		if True in results:
            			result = True
            	return result
            self.writeVInt(len(i["Rewards"]))
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])
            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"]) # new price
            self.writeVInt(i["Time"]) # timer until gone
            self.writeVInt(2)
            self.writeVInt(0)
            if i["BundleID"] in player.PurchasedOffers or checkAvailability() == True:
            	self.writeBoolean(True) # Claim
            else:
            	self.writeBoolean(i['Claim']) # Claim
            self.writeVInt(ShopData["Offers"].index(i))
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeVInt(i["OldPrice"]) # old price
            if i["Text"] == "None":
            	self.writeString()
            else:
            	self.writeString(i["Text"])
            self.writeVInt(0)
            self.writeBoolean(i["LoadOnStartup"])
            if i["Background"] == "None":
            	self.writeString()
            else:
            	self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString("")
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(False)
            self.writeDataReference(i["ShopPanelLayout"][0], i["ShopPanelLayout"][1])
            self.writeDataReference(i["ShopStyleSet"][0], i["ShopStyleSet"][1]) #panel layout
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(i["OfferType"])
            # 1 daily reward
            # 2 jackpot daily reward
            # 3 sum deleted shit like da starpoint shop maybe
            # 4 skins
            # 5 idk
            self.writeVInt(-1)
            self.writeVInt(i["Cost"])
            self.writeBoolean(False) #шваль если тру то все офферы исчезают
            self.writeBoolean(True)
            self.writeVInt(6500)
            self.writeVInt(1929)
            self.writeBoolean(True)
            
        

        

        self.writeVInt(20) # tokens for battle
        self.writeVInt(1428) # timer until new token

        self.writeVInt(0) #count

        self.writeVInt(1) #unk
        self.writeVInt(30) #unk

        self.writeByte(1) # count brawlers selected
        self.writeDataReference(16, player.SelectedBrawler) # selected brawler
        self.writeString("RO") # location
        self.writeString("CombatBrawl") # supported creator

        self.writeVInt(6) # count
        self.writeVInt(1) # resources id
        self.writeVInt(9) # resources gained
        self.writeVInt(1) # resources id
        self.writeVInt(22) # resources gained
        self.writeVInt(3) # resources id
        self.writeVInt(25) # resources gained
        self.writeVInt(1) # resources id
        self.writeVInt(24) # resources gained
        self.writeVInt(0) # resources id
        self.writeVInt(15) # resources gained
        self.writeVInt(32447) # resources id
        self.writeVInt(28) # resources gained




        self.writeVInt(0) # count 0

        self.writeVInt(20) # count brawl pass seasons
        for season in range(20):
            self.writeVInt(season) # season
            self.writeVInt(player.Tokens) # season token collected
            self.writeBoolean(player.BrawlPassActive) # 0x1
            self.writeVInt(56)
            self.writeBoolean(False)
            self.writeBoolean(True) # 0x1
            self.writeInt(player.Pass32Int)
            self.writeInt(player.Pass64Int)
            self.writeInt(player.Pass96Int)
            self.writeInt(1)
            self.writeBoolean(True) # 0x0
            self.writeInt(player.Pass32IntP)
            self.writeInt(player.Pass64IntP)
            self.writeInt(player.Pass96IntP)
            self.writeInt(1)

        self.writeVInt(0)


        self.writeBoolean(True) # 0x1
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(0) # club league quest count

        self.writeBoolean(True)
        self.writeVInt(ownedPinsCount + ownedThumbnailCount + ownedTitlesCount) # VanityCount
        for i in player.OwnedPins:
            self.writeDataReference(52, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        for i in player.OwnedThumbnails:
            self.writeDataReference(28, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)  
                    
        for i in player.OwnedTitles:
            self.writeDataReference(76, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)


        self.writeBoolean(False) # Power league season data

        self.writeInt(0)
        self.writeVInt(1)
        self.writeVInt(16)
        self.writeVInt(player.FavouriteBrawler)
        self.writeBoolean(False) # Logic Daily Data end

        self.writeVInt(2023189) # Logic Conf Data begin

        self.writeVInt(34) # event slot id
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12) # map maker candidate
        self.writeVInt(13) # map maker winner
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18) # mystery
        self.writeVInt(19)
        self.writeVInt(20)# championship challenge
        self.writeVInt(21) 
        self.writeVInt(22)
        self.writeVInt(23)
        self.writeVInt(24)
        self.writeVInt(25)
        self.writeVInt(26)
        self.writeVInt(27)
        self.writeVInt(28)
        self.writeVInt(29)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)
        self.writeVInt(33)
        self.writeVInt(34) # hypercharge 

        eventki = [568, 589, 5, 24, 590, 19]
        
        self.writeVInt(len(eventki) + 1) # event count
        for zv in eventki:

            self.writeVInt(1)
            self.writeVInt(eventki.index(zv) + 1)
            self.writeVInt(0) #tokens reward
            self.writeVInt(3600) #timer
            self.writeVInt(0)
            self.writeDataReference(15, zv) # map id
            self.writeVInt(-1)
            self.writeVInt(2) #state
            self.writeString("")
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False) # MapMaker map structure array
            self.writeVInt(0)
            self.writeBoolean(False) # Power League array entry
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            self.writeVInt(0) # new count v51
            self.writeVInt(0) # new count v51
            self.writeVInt(0) # new count v51


        self.writeVInt(1)
        self.writeVInt(34)
        self.writeVInt(0) #tokens reward
        self.writeVInt(864000000) #timer
        self.writeVInt(0)
        self.writeDataReference(15, 100) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) # new count v51
        self.writeVInt(0) # new count v51
        self.writeVInt(0) # new count v51
        

        self.writeVInt(0) # upcoming event count
       
        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800]) # Brawler Upgrade Cost
        ByteStreamHelper.encodeIntList(self, [20, 50, 140, 280]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [150, 400, 1200, 2600]) # Shop Coins Amount
        

        self.writeVInt(0) #locked for chronos
        for x in range(0):
            self.writeDataReference(16, 61)
            self.writeInt(0)
            self.writeInt(0)


        self.writeVInt(1)
        self.writeVInt(Configuration.settings["Tema"]) # theme
        self.writeVInt(1)
        


        self.writeVInt(0) # Timed int entry count
        # self.writeVInt(31)
        # self.writeVInt(1)
        # self.writeVInt(499427)
        # self.writeVInt(758627)
        # self.writeVInt(29)
        # self.writeVInt(24)
        # self.writeVInt(0)
        # self.writeVInt(413027)
        self.writeVInt(0) # custom event

        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(4)

        ByteStreamHelper.encodeIntList(self, [0, 29, 79, 169, 349, 699]) # brawler cost gems ?
        ByteStreamHelper.encodeIntList(self, [0, 160, 450, 500, 1250, 2500]) # what is that ? looks like chroma price of chromatic brawlers but it doesn't go under 500

        self.writeLong(player.ID[0], player.ID[1]) # Player ID

        try:
        	player.Notifications
        except KeyError:
        	player.Notifications = []
        notifications = player.Notifications
        notifications.sort(key = lambda x: x["Number"], reverse = True)
        self.writeVInt(len(notifications)) # Notification Count
        for x in notifications:
        	# BaseNotification::encode
        	self.writeVInt(x["Type"])
        	self.writeInt(notifications.index(x)) # Notification Index
        	self.writeBoolean(x["Readed"]) # Read
        	self.writeInt(x["Timer"]) # Time Ago
        	self.writeString(x["Text"])
        	self.writeVInt(0)
        	if x["Type"] == 81:
        		self.writeVInt(1)
        	if x["Type"] == 72 or x["Type"] == 94:
        		# VanityItemRewardNotification or SkinRewardNotification
        		self.writeVInt(29000000 + x["Extra"])
        	if x["Type"] == 63 or x["Type"] == 70:
        		# ChallengeRewardNotification
        		self.writeVInt(1)
        		for i in range(1):
        			self.writeVInt(x["Reward"]["Type"])
        			self.writeVInt(x["Reward"]["Amount"])
        			self.writeDataReference(x["Reward"]["Brawler"][0], x["Reward"]["Brawler"][1])
        			self.writeVInt(x["Reward"]["Extra"])
        		self.writeVInt(x["ChallengeVariation"])
        		self.writeVInt(x["Win"])
        		self.writeString(x["ChallengeName"])
        	if x["Type"] == 64:
        		# BoxRewardNotification::encode
        		self.writeVInt(1)
        		self.writeVInt(x["RewardType"])
        		self.writeVInt(x["Amount"])
        	if x["Type"] == 71:
        		# BrawlPassPointRewardNotification::encode
        		self.writeVInt(x["BPSeason"])
        		self.writeVInt(x["Tokens"])
        
        self.writeVInt(1)
        self.writeBoolean(False)
        self.writeVInt(0) # gatcha drop
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeBoolean(True)
        
        LoginData = JSONHandler.LoginData
        
        self.writeVInt(0)
        self.writeVInt(len(LoginData["LoginItems"])) # amount of items in login calendar
        for x in LoginData["LoginItems"]:
        	self.writeVInt(x["Day"]) #day     	
        	self.writeVInt(len(x["Rewards"]))#count
        	for reward in x["Rewards"]:
        		self.writeVInt(reward["ItemType"])
        		self.writeVInt(reward["Amount"])
        		self.writeDataReference(16, reward["BrawlerID"][1])
        		self.writeVInt(reward["Extra"])
        		self.writeBoolean(False)
                
        
        self.writeVInt(1) # Road Count
             
        self.writeVInt(0) # Road
        self.writeVInt(1) # Reward Amount
        
        self.writeVInt(6) #day
        self.writeVInt(1) #amount
        
        self.writeVInt(45)
        self.writeVInt(2750)
        self.writeDataReference(16,0)
        self.writeVInt(0)
        self.writeBoolean(False)
                                               
        self.writeVInt(player.LoginRewardIndex)#если 1 то вылетает что ты не получишь награду
        self.writeVInt(9339)# настя сво
        self.writeVInt(9339)
        self.writeVInt(player.ClaimedLoginRewardIndex)
        self.writeVInt(0) 
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        # new function v46
        self.writeVInt(0) # new function v46
        self.writeBoolean(True) 
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        if True:
            self.writeVInt(1)
        
            rare = [1, 2, 3, 6, 8, 10, 13, 24]
            super_rare = [7, 9, 18, 19, 22, 25, 27, 34, 61, 4]
            epic = [14, 15, 16, 20, 26, 29, 30, 36, 43, 45, 48, 50, 58, 69]
            mythic = [11, 17, 21, 35, 31, 32, 37, 42, 47, 64, 67, 71, 73]
            legendary = [5, 12, 23, 28, 40, 52, 63]
        
            x = player.RecruitBrawler
        
            self.writeDataReference(16, player.RecruitBrawler) 
            
            if x in rare:
                self.writeVInt(160)
            elif x in super_rare:
                self.writeVInt(430)
            elif x in epic:
                self.writeVInt(925)
            elif x in mythic:
               self.writeVInt(1900)
            elif x in legendary:
                self.writeVInt(3800)
            else:
                self.writeVInt(1)
            
            
            if x in rare:
                self.writeVInt(29)
            elif x in super_rare:
                self.writeVInt(79)
            elif x in epic:
                self.writeVInt(169)
            elif x in mythic:
                self.writeVInt(359)
            elif x in legendary:
                self.writeVInt(699)
            else:
                self.writeVInt(1)
            
            self.writeVInt(0)
            self.writeVInt(player.RecruitTokens) 
            self.writeVInt(0) 
            self.writeVInt(0)
        else:
        	self.writeVInt(0)
        
        
        self.writeVInt(len(player.Brawlers))
        for x in player.Brawlers:
            self.writeDataReference(16, x) 
                      
            
            if x in rare:
                self.writeVInt(160)
            elif x in super_rare:
                self.writeVInt(430)
            elif x in epic:
                self.writeVInt(925)
            elif x in mythic:
                self.writeVInt(1900)
            elif x in legendary:
                self.writeVInt(3800)
            else:
            	self.writeVInt(1)
            
            
            if x in rare:
                self.writeVInt(29)
            elif x in super_rare:
                self.writeVInt(79)
            elif x in epic:
                self.writeVInt(169)
            elif x in mythic:
                self.writeVInt(359)
            elif x in legendary:
                self.writeVInt(699)
            else:
            	self.writeVInt(1)
            
           
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(player.Brawlers.index(x)) 
            self.writeVInt(0)
        
        self.writeVInt(0)
        
        self.writeVInt(0) 
        # Starr Road End
        
       
        
        self.writeVInt(len(player.OwnedBrawlers)) # new function v48
        for brawlerID,brawlerInfo in player.OwnedBrawlers.items():           
            self.writeVInt(brawlerInfo["MasteryPoints"])
            self.writeVInt(brawlerInfo["MasteryTier"])
            self.writeDataReference(16, brawlerID)
        

        self.writeVInt(0) # v48
        if player.BattleIcon1Visible == True:
        	self.writeDataReference(28, player.BattleIcon1)
        else:
        	self.writeDataReference(0)
        if player.BattleIcon2Visible == True:
        	self.writeDataReference(28, player.BattleIcon2)
        else:
        	self.writeDataReference(0)
        if player.BattleEmoteVisible == True:
        	self.writeDataReference(52, player.BattleEmote)
        else:
        	self.writeDataReference(0)
        if player.TitleVisible == True:
        	self.writeDataReference(76, player.Title)
        else:
        	self.writeDataReference(0)
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48

        self.writeVInt(0)

        # v50 this is starr drop thing
        starrDropOpening.encode(self, player)
        #self.writeVInt(0) # end LogicClientHome

        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeStringReference(player.Name)
        self.writeBoolean(player.Registered)
        self.writeInt(-1)

        self.writeVInt(17) 
        self.writeVInt(8 + ownedBrawlersCount)
        for brawlerInfo in player.OwnedBrawlers.values():
            self.writeDataReference(23, brawlerInfo["CardID"])
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins) 
        
        self.writeDataReference(5, 9)
        self.writeVInt(-1)
        self.writeVInt(1) 

        self.writeDataReference(5, 10)
        self.writeVInt(-1)
        self.writeVInt(0) 

        self.writeDataReference(5, 13)
        self.writeVInt(-1)
        self.writeVInt(0) 
        
        self.writeDataReference(5, 20)
        self.writeVInt(-1)
        self.writeVInt(player.ChromaticCoins) 
        
        self.writeDataReference(5, 21)
        self.writeVInt(-1)
        self.writeVInt(0)     
        
        self.writeDataReference(5, 22)
        self.writeVInt(-1)
        self.writeVInt(player.PowerPoints) 

        self.writeDataReference(5, 23)
        self.writeVInt(-1)
        self.writeVInt(player.Bling) 

        self.writeVInt(ownedBrawlersCount)

        for brawlerID,brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["Trophies"])
        
        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["HighestTrophies"])

        self.writeVInt(0) 

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["PowerPoints"])
        
        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["PowerLevel"] - 1)

        Accessories = player.OwnedAccessories
        self.writeVInt(len(Accessories))  # Count
        for x in Accessories:
            self.writeDataReference(23, x)  # Cards ID
            self.writeVInt(1)
            self.writeVInt(1)  # Star Power Unlocked State
        # Brawlers Star Powers Array End # 

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["State"])

        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array

        self.writeVInt(player.Gems) # Diamonds
        self.writeVInt(player.Gems) # Free Diamonds
        self.writeVInt(10) # Player Level
        self.writeVInt(100)
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(100) # Battle Count
        self.writeVInt(10) # WinCount
        self.writeVInt(80) # LoseCount
        self.writeVInt(50) # WinLooseStreak
        self.writeVInt(20) # NpcWinCount
        self.writeVInt(0) # NpcLoseCount
        self.writeVInt(2) # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(12)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)

        

    def decode(self):
        fields = {}
        # fields["AccountID"] = self.readLong()
        # fields["HomeID"] = self.readLong()
        # fields["PassToken"] = self.readString()
        # fields["FacebookID"] = self.readString()
        # fields["GamecenterID"] = self.readString()
        # fields["ServerMajorVersion"] = self.readInt()
        # fields["ContentVersion"] = self.readInt()
        # fields["ServerBuild"] = self.readInt()
        # fields["ServerEnvironment"] = self.readString()
        # fields["SessionCount"] = self.readInt()
        # fields["PlayTimeSeconds"] = self.readInt()
        # fields["DaysSinceStartedPlaying"] = self.readInt()
        # fields["FacebookAppID"] = self.readString()
        # fields["ServerTime"] = self.readString()
        # fields["AccountCreatedDate"] = self.readString()
        # fields["StartupCooldownSeconds"] = self.readInt()
        # fields["GoogleServiceID"] = self.readString()
        # fields["LoginCountry"] = self.readString()
        # fields["KunlunID"] = self.readString()
        # fields["Tier"] = self.readInt()
        # fields["TencentID"] = self.readString()
        #
        # ContentUrlCount = self.readInt()
        # fields["GameAssetsUrls"] = []
        # for i in range(ContentUrlCount):
        #     fields["GameAssetsUrls"].append(self.readString())
        #
        # EventUrlCount = self.readInt()
        # fields["EventAssetsUrls"] = []
        # for i in range(EventUrlCount):
        #     fields["EventAssetsUrls"].append(self.readString())
        #
        # fields["SecondsUntilAccountDeletion"] = self.readVInt()
        # fields["SupercellIDToken"] = self.readCompressedString()
        # fields["IsSupercellIDLogoutAllDevicesAllowed"] = self.readBoolean()
        # fields["isSupercellIDEligible"] = self.readBoolean()
        # fields["LineID"] = self.readString()
        # fields["SessionID"] = self.readString()
        # fields["KakaoID"] = self.readString()
        # fields["UpdateURL"] = self.readString()
        # fields["YoozooPayNotifyUrl"] = self.readString()
        # fields["UnbotifyEnabled"] = self.readBoolean()
        # super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion