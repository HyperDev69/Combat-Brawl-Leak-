 
        self.writeVInt(2) # shop offers count
        
        
        self.writeVInt(1) # reward count
        self.writeVInt(49) # item type
        self.writeVInt(10) # quantity
        self.writeDataReference(0)# csv reference
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(0) # new price
        self.writeVInt(17280000) # timer until gone
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(8881)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0) # old price
        self.writeStringReference("WELCOME TO COMBAT BRAWL!") # title
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeString("offer_wasteland")
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(1)
        self.writeVInt(0) # offer value
        self.writeString("")
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(-1)
        self.writeVInt(1)
        # v51
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(1) # reward count
        self.writeVInt(49) # item type
        self.writeVInt(10) # quantity
        self.writeDataReference(0)# csv reference
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(0) # new price
        self.writeVInt(17280000) # timer until gone
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(8881)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0) # old price
        self.writeStringReference("WELCOME TO COMBAT BRAWL!") # title
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeString("offer_wasteland")
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(1)
        self.writeVInt(0) # offer value
        self.writeString("")
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(-1)
        self.writeVInt(1)
        # v51
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)