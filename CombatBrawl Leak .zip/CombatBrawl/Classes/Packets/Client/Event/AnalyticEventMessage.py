from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Messaging import Messaging

from Classes.ByteStream import ByteStream
import json


ShopUpdated = False

class AnalyticEventMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def decode(self):
        fields = {}
        fields["Type"] = self.readString()
        fields["Event"] = self.readString()
        print(fields)
        return fields

    def encode(self):
    	pass
    
    def execute(message, calling_instance, fields, cryptoInit):
        print("Type:", fields["Type"], "Event:", fields["Event"])

    def getMessageType(self):
        return 10110

    def getMessageVersion(self):
        return self.messageVersion