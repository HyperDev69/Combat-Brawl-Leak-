from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage

from datetime import datetime

from Database.DatabaseHandler import DatabaseHandler

import random


class KeepAliveMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        return {}

    def execute(message, calling_instance, fields, cryptoInit):
        
        def updateDrops():
        	db_instance.updatePlayerData(playerData, calling_instance)
        	fields["StarrDrops"] = False
        	fields["Wins"] = 0
        	fields["Offer"] = 2479285701
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 228}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	
        def addDay():
        	if playerData["ClaimedLoginRewardIndex"] < 6:
        		playerData["LoginRewardIndex"] += 1
        	else:
        		pass
        	db_instance.updatePlayerData(playerData, calling_instance)
        		
        def updateDailyFreebies():
        	daily_freebie_items = [38, 41, 1, 45]
        	daily_freebie_item_chance = random.randint(1, 60000)
        	jackpot_values = [200, 300, 500, 700, 600, 650, 620, 250, 350, 450, 470]
        	if daily_freebie_item_chance >= 40000:
        		jackpot_state = 1
        		random_cumulative = random.randint(10, 50)
        	else:
        		jackpot_state = 2
        		random_cumulative = random.choice(jackpot_values)
        	playerData["DailyFreebieItem"] = random.choice(daily_freebie_items)
        	
        	playerData["DailyFreebieItemAmount"] = random_cumulative
        	playerData["DailyFreebieClaimed"] = False
        	playerData["Jackpot"] = jackpot_state
        	db_instance.updatePlayerData(playerData, calling_instance)
        	
        def updateOfferSlots():
        	random_slot_offers = [{"Item": 41, "Title": 'АКЦИЯ К ПОВЫШЕНИЮ УРОВНЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 1, "Title": 'АКЦИЯ К ПОВЫШЕНИЮ УРОВНЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 49, "BGR": 'offer_starter_pack', "Amount": 250, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 79, "BGR": 'offer_starter_pack', "Amount": 500, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 79, "BGR": 'offer_starter_pack', "Amount": 500, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}, {"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 99, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}]
        	playerData["OfferSlot1"].clear()
        	playerData["OfferSlot2"].clear()
        	playerData["OfferSlot3"].clear()
        	playerData["OfferSlot1"].append(random.choice(random_slot_offers))
        	playerData["OfferSlot2"].append(random.choice(random_slot_offers))
        	playerData["OfferSlot3"].append(random.choice(random_slot_offers))

        	
        db_instance = DatabaseHandler()       
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        Day = playerData["LoginDay"]
        Month = playerData["LoginMonth"]
        Year = playerData["LoginYear"]
        Index = playerData["LoginRewardIndex"]
        Wins = playerData["DailyWins"]
        currDate = datetime.strptime(f'{Day}.{Month}.{Year} 00:00', "%d.%m.%Y %H:%M").timestamp()
        timeEquation = currDate - datetime.now().timestamp()
        if int(timeEquation) <= 0:      	
        	if Day == 31 and Month == 1:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 2
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 28 and Month == 2:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 3
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 31 and Month == 3:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 4
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 30 and Month == 4:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 5
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 31 and Month == 5:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 6
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 30 and Month == 6:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 7
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 31 and Month == 7:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 8
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 31 and Month == 8:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 9
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 30 and Month == 9:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 10
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 31 and Month == 10:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 11
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 30 and Month == 11:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 12
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	elif Day == 31 and Month == 12:
        		playerData["LoginDay"] = 1
        		playerData["LoginMonth"] = 1
        		playerData["LoginYear"] += 1
        		addDay()
        		playerData["DailyWins"] = 0
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()
        	else:
        		addDay()
        		playerData["DailyWins"] = 0
        		playerData["LoginDay"] += 1
        		updateDailyFreebies()
        		updateDrops()
        		updateOfferSlots()  		
        db_instance.updatePlayerData(playerData, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(20108, fields, cryptoInit)
        
        

    def getMessageType(self):
        return 10108

    def getMessageVersion(self):
        return self.messageVersion