class LogicSaveData:
   pass