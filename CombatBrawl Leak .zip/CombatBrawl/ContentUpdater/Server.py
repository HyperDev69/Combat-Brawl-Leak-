import http.server
import os
import socketserver
import socket

PORT = 9339
Handler = http.server.SimpleHTTPRequestHandler
os.chdir("Update")
with socketserver.TCPServer(("", 9339), Handler) as httpd:
    print("Server is ready")
    httpd.serve_forever()
