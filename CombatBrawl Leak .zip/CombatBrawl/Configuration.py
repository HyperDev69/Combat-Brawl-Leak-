# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

settings = {
     # Server Settings
    "DisableNagle": True,
    "PrintEnabled": True,
    "Tema" : 41000010,
    "Maintance": False,
    "MaintanceTime": 3600,
    "UpdateURL": "https://discord.com/invite/q2XCMVxr", # replace google.com with any website, i put my discord server for candybrawl
    "DoubleTokenEvent": False,
    "GoldRushEvent": True,
}