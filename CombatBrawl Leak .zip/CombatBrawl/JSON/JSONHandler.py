import json

class JSONHandler:
    ShopData = json.loads(open("CombatBrawl/JSON/Shop/Shop.json", 'r').read())
    RareDropsData = json.loads(open("CombatBrawl/JSON/DropsData/RareDropsData.json", 'r').read())
    SuperRareDropsData = json.loads(open("CombatBrawl/JSON/DropsData/SuperRareDropsData.json", 'r').read())
    EpicDropsData = json.loads(open("CombatBrawl/JSON/DropsData/EpicDropsData.json", 'r').read())
    MythicDropsData = json.loads(open("CombatBrawl/JSON/DropsData/MythicalDropsData.json", 'r').read())
    LegendaryDropsData = json.loads(open("CombatBrawl/JSON/DropsData/LegendaryDropsData.json", 'r').read())
    LoginData = json.loads(open("CombatBrawl/JSON/LoginRewards/LoginRewards.json", 'r').read())

    def Preload():
        JSONHandler.ShopData = json.loads(open("CombatBrawl/JSON/Shop/Shop", 'r').read())