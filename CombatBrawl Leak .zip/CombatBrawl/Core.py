serverAddress = ("0.0.0.0", 9339)

from Static.StaticData import StaticData
import Configuration

import socket
from Classes.Connection import Connection
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
server.bind(serverAddress)
print(f"CombatBrawl: Server binded: {serverAddress[0]}:{serverAddress[1]}")
while True:
    server.listen()
    socket, address = server.accept()
    print(f"CombatBrawl: New client connection: {address[0]}:{address[1]}")
    Connection(socket, address).start()
    from Classes.ServerConnection import ServerConnection

StaticData.Preload()

ServerConnection(("0.0.0.0", 9339))